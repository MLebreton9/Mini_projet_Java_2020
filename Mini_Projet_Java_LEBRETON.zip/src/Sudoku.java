import java.util.ArrayList;
import java.util.Collections;

public class Sudoku {
	private int grilleSolution[][];//Grille de r�ference contenant la solution g�n�r�e par la suite
	private int grille[][];//Grille montr�e et remplie par le joueur
	private int grilleTemp[][];//Grille servant � g�nerer la grille pr�cedente

	public Sudoku() {//Constructeur
		grilleSolution = new int[9][9];
		grille = new int[9][9];
		grilleTemp = new int[9][9];
		for(int i=0;i<9;i++) {
			for(int j=0;j<9;j++) {
				this.grilleSolution[i][j] = 0;
				this.grille[i][j] = 0;
				this.grilleTemp[i][j] = 0;
			}
		}
	}//On initialise les 3 grilles de 9x9 � 0;

	public boolean isInRow(int row, int number) {//M�thode permettant de v�rifier si le nombre "number" est deja dans la ligne ou non.
		for(int i=0;i<9;i++) {
			if(grilleSolution[row][i] == number)
				return true;
		}
		return false;
	}

	public boolean isInColumn(int col, int number) {//M�thode permettant de v�rifier si le nombre "number" est deja dans la colonne ou non.
		for(int i=0;i<9;i++) {
			if(grilleSolution[i][col] == number)
				return true;
		}
		return false;
	}

	private boolean isInBox(int row, int col, int number) {//M�thode permettant de v�rifier si le nombre "number" est deja dans le carr� 3x3 correspondant ou non.
		int r = row - row % 3;
		int c = col - col % 3;

		for(int i = r; i < r+3; i++) {
			for(int j = c; j < c+3; j++) {
				if(grilleSolution[i][j] == number)
					return true;
			}
		}
		return false;
	}

	private boolean isOk(int row, int col, int number) {//M�thode combinant les trois pr�cedentes afin de v�rifier si on peut placer le nombre � la position choisie
		return !isInRow(row, number) && !isInColumn(col, number) &&  !isInBox(row, col, number);//M�thode utilis�e pour g�n�rer la grille de soultion
	}
	
	//Les 4 m�thodes suivantes ont les m�me fonctionnalit�s que les pr�c�dentes mais servent pour g�n�rer la grille du joueur
	public boolean solveInRow(int row, int number) {
		for(int i=0;i<9;i++) {
			if(grille[row][i] == number)
				return true;
		}
		return false;
	}

	public boolean solveInColumn(int col, int number) {
		for(int i=0;i<9;i++) {
			if(grille[i][col] == number)
				return true;
		}
		return false;
	}

	private boolean solveInBox(int row, int col, int number) {
		int r = row - row % 3;
		int c = col - col % 3;

		for(int i = r; i < r+3; i++) {
			for(int j = c; j < c+3; j++) {
				if(grille[i][j] == number)
					return true;
			}
		}
		return false;
	}

	private boolean solveOk(int row, int col, int number) {
		return !solveInRow(row, number) && !solveInColumn(col, number) &&  !solveInBox(row, col, number);
	}

	public boolean generationGrilleSolution() {//M�thode r�cursive qui g�n�re la grille de solution
		ArrayList<Integer> numberList = new ArrayList<>();
		for(int i=1; i<10; i++) {
			numberList.add(i);
		}//On cr�e une liste contenant les chiffres de 0 � 9
		Collections.shuffle(numberList);//On m�lange la liste de chiffres pour pouvoir g�n�rer des grilles diff�rentes � chaque utilisation

		for (int row = 0; row < 9; row ++) {
			for(int col = 0; col < 9; col ++) {//On parcourt la grille
				if(grilleSolution[row][col] == 0) {//On v�rifie qu'on est dans une case vide
					for (int number : numberList) {//On prend les nombres dans la liste
						if(isOk(row, col, number)) {//On v�rifie qu'on peut le placer
							grilleSolution[row][col] = number;//On le place
							if (generationGrilleSolution()) {//On execute r�cursivement cette m�thode jusqu'� qu'on ne puisse plus mettre de chiffres
								return true;
							} else {
								grilleSolution[row][col] = 0;//Si on ne peut pas placer le chiffre suivant, on enleve le chiffre et on continue avec un autre
							}
						}
					}
					return false;
				}
			}
		}
		for(int i=0;i<9;i++) {
			for(int j=0;j<9;j++) {
				grille[i][j] = grilleSolution[i][j];//On remplit la grille du joueur avec la grille de solution
			}
		}
		return true;
	}

	public boolean solve() {//M�thode identique � generationGrilleSolution mais pour la grille du joueur
		ArrayList<Integer> numberList = new ArrayList<>();
		for(int i=1; i<10; i++) {
			numberList.add(i);
		}
		Collections.shuffle(numberList);
		for (int row = 0; row < 9; row ++) {
			for(int col = 0; col < 9; col ++) {
				if(grille[row][col] == 0) {
					for (int number : numberList) {
						if(solveOk(row, col, number)) {
							grille[row][col] = number;
							if (solve()) {
								return true;
							}
							else {
								grille[row][col] = 0;
							}
						}
					}
					return false;
				}
			}
		}
		return true;
	}
	
	public boolean countSolution() {//M�thode permettant de v�rifier qu'il n'y a qu'une solution pour la grille du joueur
		for(int c=0;c<5; c++) {// On r�alise 5 essais afin de s'assurer qu'il n'y a pas deux solutions
			for(int i=0; i<9; i++) {
				for(int j=0;j<9;j++) {
					grilleTemp[i][j] = grille[i][j];//On utilise la grille temporaire car la m�thode solve() va remplir la grille du joueur
				}
			}
			solve();//On utilise la m�thode solve();
			if(!compareGrille()) {//On v�rifie que la grille est identique � la grille solution
				return false;
			}
			for(int i=0; i<9; i++) {//On revide la grille grace a la grille temporaire afin de faire un deuxi�me essai avec une liste de nombres dans un ordre diff�rent
				for(int j=0;j<9;j++) {
					grille[i][j] = grilleTemp[i][j];
				}
			}
		}
		return true;
	}

	public void preparationGrille(int difficulte) {//M�thode qui vide la grille petit � petit. Le nombre de cases enlev�es d�pend de la difficult� choisie
		int nbCasesVides = 0;
		while(nbCasesVides < difficulte) {
			int i = (int)(Math.random()*9);
			int j = (int)(Math.random()*9);
			int temp = grille[i][j];
			if(grille[i][j] != 0) {
				grille[i][j] = 0;
				if(countSolution()) {//On compte les solutions
					nbCasesVides++;
				}
				else {
					grille[i][j] = temp;
				}
			}
		}
	}


	public void afficherGrille() {//On affiche la grille du joueur
		System.out.println("Grille � remplir");
		for(int i=0;i<9;i++) {
			for(int j=0;j<9;j++) {
				if(grille[i][j] == 0) {
					System.out.print("  ");
				}
				else {
					System.out.print(this.grille[i][j] + " ");
				}
			}
			System.out.println();
		}
		System.out.println();
	}
	
	public void afficherGrilleSolution() {//On affiche la grille de solution
		System.out.println("Voici la grille de solution");
		for(int i=0;i<9;i++) {
			for(int j=0;j<9;j++) {
				System.out.print(this.grilleSolution[i][j] + " ");
			}
			System.out.println();
		}
		System.out.println();
	}
	
	//Getters & Setters
	
	public int[][] getGrilleSolution() {
		return grilleSolution;
	}
	
	public int getGrilleSolution(int i, int j) {
		return grilleSolution[i][j];
	}

	public void setGrilleSolution(int[][] grilleSolution) {
		this.grilleSolution = grilleSolution;
	}

	public int[][] getGrille() {
		return grille;
	}
	
	public int getGrille(int i, int j) {
		return grille[i][j];
	}

	public void setGrille(int i, int j, int number) {
		this.grille[i][j] = number;
	}
	
	
	public boolean compareGrille(){//On compare la grille du joueur et la grille de solution
		for(int i=0;i<9;i++) {
			for(int j=0;j<9;j++) {
				if(this.grille[i][j] != this.grilleSolution[i][j]) {
					return false;
				}
			}
		}
		return true;
	}
}
