import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Sudoku jeu = new Sudoku();//On cr�e une instance du jeu
		Scanner scanner = new Scanner(System.in);//On instancie le scanner afin de lire les entr�es
		jeu.generationGrilleSolution();//On g�nere la grille de solution
		System.out.println("Choisissez le niveau de difficult� :\n1: Facile\n2: Normal\n3: Difficile");
		int difficulte;
		boolean echec = false;
		do {//On demande la difficult� au joueur jusqu'� ce qu'il ait rentr� un nombre valide
			difficulte = scanner.nextInt();
			switch(difficulte) {
			case 1: jeu.preparationGrille(25);break;
			case 2: jeu.preparationGrille(36);break;
			case 3: jeu.preparationGrille(49);System.out.println("La g�n�ration peut prendre du temps, la grille se cr�e");break;
			default: System.out.println("Difficult� non disponible");
			}
		}while((difficulte < 1) || (difficulte > 3));
		System.out.println("Grille g�n�r�e !");
		while(!jeu.compareGrille()) {//On fait tourner le jeu jusqu'a ce que la grille soit remplie correctement
			jeu.afficherGrille();
			System.out.println("Faites un choix :\n1: Remplir une case\n2: Demander de l'aide\n3: Afficher les erreurs commises\n4: Effacer une case\n5: Renoncer et afficher la solution");
			int choix = 0;
			do {
				choix = scanner.nextInt();
				switch(choix) {//On laisse � l'utilisateur un choix d'actions
				case 1 ://Remplir une case
					int i=0, j=0, number=0;
					do {//On lui demande successivement de doner les coordonn�es puis le nombre � entrer en v�rifiant la validit�.Le joueur peut, s'il le d�sire reremplir une case d�j� remplie
						System.out.println("Entrez la coordonn�e verticale de la case � remplir (entre 1 et 9)");
						i = scanner.nextInt();
					}while((i < 1) || (i > 9));
					do {
						System.out.println("Entrez la coordonn�e horizontale de la case � remplir (entre 1 et 9)");
						j = scanner.nextInt();
					}while((j < 1) || (j > 9));
					do {
						System.out.println("Entrez le nombre � entrer dans la case : " + i + "," + j +  " (entre 1 et 9)");
						number = scanner.nextInt();
					}while((number < 1) || (number > 9));
					jeu.setGrille(i-1, j-1, number);//On remplit la grille
					break;
				case 2 ://Aide apport�e au joueur : deux choix : remplir une case choisie au hasard ou par le joueur
					int choix2;
					System.out.println("Quelle aide voulez-vous ?\n1: Remplir une case au hasard\n2: Choisir une case � remplir");
					choix2 = scanner.nextInt();
					switch(choix2) {//Le joueur choisit l'aid e qu'il veut
					case 1://On choisit deux nombres au hasard jusqu'a ce que la case soit vide et on remplit la case avec la valeur correspondante dans le grille de solution
						int k = 10, l = 10;
						do {
							k = (int)(Math.random()*9);
							l = (int)(Math.random()*9);
						}while(jeu.getGrille(k, l) != 0);
						jeu.setGrille(k, l, jeu.getGrilleSolution(k, l));
						break;
					case 2://L'utilisateur choisit une case et on remplit la case choisie de la m�me mani�re
						k=0;l=0;
						do {
							System.out.println("Entrez la coordonn�e verticale de la case � remplir (entre 1 et 9)");
							k = scanner.nextInt();
						}while((k < 1) || (k > 9));
						do {
							System.out.println("Entrez la coordonn�e horizontale de la case � remplir (entre 1 et 9)");
							l = scanner.nextInt();
						}while((l < 1) || (l > 9));
						jeu.setGrille(k-1, l-1, jeu.getGrilleSolution(k-1, l-1));
						break;
					}
					break;
				case 3://On affiche les erreurs commises par le joueur, sans toutefois les corriger
					int erreur = 0;
					for(int m=0;m<9;m++) {//On parcourt la grille � la rechercher de dissimilutudes avec la grille de solutions
						for(int p=0;p<9;p++) {
							if((jeu.getGrille(m, p) != jeu.getGrilleSolution(m, p)) && (jeu.getGrille(m, p) != 0)) {
								System.out.println("La case " + (m+1) + "," + (p+1) + " est mal remplie");
								erreur++;
							}
						}
					}
					if(erreur == 0) {//On r�capitule le nombre d'erreurs
						System.out.println("Aucune erreur n'a �t� commise");
					}
					else if(erreur == 1) {
						System.out.println("1 erreur a �t� commise");
					}
					else {
						System.out.println(erreur + " erreurs ont �t� commises");
					}
					break;
				case 4://Le joueur d�cide d'effacer la valeur contenue dans une case. On proc�de de la mani�re que pour la remplir, mais on v�rifie qu'elle est pleine
					int k=10, l=10;
					do {
						do {
							System.out.println("Entrez la coordonn�e verticale de la case � effacer (entre 1 et 9)");
							k = scanner.nextInt();
						}while((k < 1) || (k > 9));
						do {
							System.out.println("Entrez la coordonn�e horizontale de la case � effacer (entre 1 et 9)");
							l = scanner.nextInt();
						}while((l < 1) || (l > 9));
					}while(jeu.getGrille(k-1, l-1) == 0);
					jeu.setGrille(k-1, l-1, 0);
					break;
				case 5://Le joueur renonce, on affiche la grille et on met la variable echec � true pour ne pas afficher victoire par la suite
					jeu.afficherGrilleSolution();
					for(i=0;i<9;i++) {//On remplit �galement la grille du joueur avec la grille de solution afin de terminer le jeu
						for(j=0;j<9;j++) {
							jeu.setGrille(i, j, jeu.getGrilleSolution(i,  j));
						}
					}
					echec = true;
					break;
				}
			}while((choix < 1) || (choix > 5));
		}
		if(echec) {//On affiche echec ou victoire selon si le joueur a renonc� ou rempli la grille
			System.out.println("Echec");
		}
		else {
			System.out.println("Victoire");
		}
		scanner.close();
	}
}
